import React from "react";

const View = () => {
  return <div className="text-black">View</div>;
};

export default View;
