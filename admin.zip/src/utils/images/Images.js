const Images = [
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBXWiJk_8-7nHFH3q3L4reHdP-741TbvaZfA&usqp=CAU",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVgbN8sw77WoeHjnfn31dWSiA2WPWO459BnA&usqp=CAU",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYfXeEXMUn9PPZKN7cbCMMDLxwGzGhTreuFg&usqp=CAU",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTN7BS0OcxS02X5lIutLO5TX1wr_V8DQQfekg&usqp=CAU",
];

export default Images;
